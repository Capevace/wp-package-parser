=== Test Plugin ===
Contributors: capevace
Tags: one, two
Requires at least: 3.8
Tested up to: 4.9
WC requires at least: 2.4
WC tested up to: 3.3
Stable tag: 2.0.0
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Plugin short description.

== Description ==

Description here.

== Installation ==

Installation here.

== Frequently Asked Questions ==

= Question =

Answer

= Question 2 =

Answer 2

== Screenshots ==

1. WooCommerce Germanized Settings

== Changelog ==

= 2.0.0 =
* Improvement

= 1.0.0 =
* Initial Version

== Upgrade Notice ==

= 2.0.0 =
Upgrade Notice